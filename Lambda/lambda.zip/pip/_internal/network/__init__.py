"""Contains purely network-related utilities.
"""
